"use client"

import { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { X, Plus, ChevronLeft, ChevronRight, Search } from "lucide-react"

interface Song {
  title: string
  verses: string[][]
  chorus?: string[]
  formated?: boolean
  chorusFirst?: boolean
}

export default function HeroSection() {
  const [searchQuery, setSearchQuery] = useState("")
  const [songs, setSongs] = useState<Song[]>([])
  const [searchResults, setSearchResults] = useState<Song[]>([])
  const [selectedSong, setSelectedSong] = useState<Song | null>(null)
  const [currentSlide, setCurrentSlide] = useState(0)
  const [showFullScreen, setShowFullScreen] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const loadSongs = async () => {
      try {
        const response = await fetch("/songs.json")
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`)
        }
        const data = await response.json()
        if (!Array.isArray(data)) {
          throw new Error("Data is not an array")
        }
        setSongs(data)
      } catch (error) {
        console.error("Error loading songs:", error)
        setError("Failed to load songs. Please try again later.")
        // You might want to set an error state here to display to the user
        setSongs([]) // Set to empty array to avoid undefined errors
      }
    }
    loadSongs()
  }, [])

  // Update search results whenever searchQuery changes
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([])
      return
    }

    const normalizedQuery = searchQuery.toLowerCase().trim()
    const results = songs.filter((song) => {
      // Search in title
      if (song.title.toLowerCase().includes(normalizedQuery)) return true

      // Search in verses
      if (song.verses.some((verse) => verse.some((line) => line.toLowerCase().includes(normalizedQuery)))) return true

      // Search in chorus if exists
      if (song.chorus && song.chorus.some((line) => line.toLowerCase().includes(normalizedQuery))) return true

      return false
    })

    setSearchResults(results)
  }, [searchQuery, songs])

  const handleSongSelect = (song: Song) => {
    setSelectedSong(song)
    setCurrentSlide(0)
    setShowFullScreen(true)
    setSearchQuery("")
    setSearchResults([])
  }

  const formatSongContent = (song: Song) => {
    let content: string[] = []
    if (song.chorusFirst && song.chorus) {
      content = [...song.chorus]
    }
    song.verses.forEach((verse, idx) => {
      content.push(...verse)
      if (song.chorus && !song.chorusFirst && idx < song.verses.length - 1) {
        content.push(...song.chorus)
      }
    })
    return content
  }

  const handleNextSlide = () => {
    if (selectedSong) {
      const maxSlides = formatSongContent(selectedSong).length
      setCurrentSlide((prev) => (prev < maxSlides - 1 ? prev + 1 : prev))
    }
  }

  const handlePrevSlide = () => {
    setCurrentSlide((prev) => (prev > 0 ? prev - 1 : prev))
  }

  return (
    <div className="space-y-4">
      {error && <div className="text-red-500 text-center mb-4">{error}</div>}
      <div className="relative max-w-xl mx-auto">
        <Input
          type="search"
          placeholder="ابحث عن ترنيمة..."
          className="w-full pl-12"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
      </div>

      {searchResults.length > 0 && (
        <Card className="absolute z-10 w-full max-w-xl mx-auto mt-1 p-2">
          <div className="max-h-60 overflow-y-auto">
            {searchResults.map((song, index) => (
              <Button
                key={index}
                variant="ghost"
                className="w-full text-right hover:bg-accent"
                onClick={() => handleSongSelect(song)}
              >
                {song.title}
              </Button>
            ))}
          </div>
        </Card>
      )}

      {showFullScreen && selectedSong && (
        <div className="fixed inset-0 bg-black z-50 flex flex-col">
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-4 left-4"
            onClick={() => setShowFullScreen(false)}
          >
            <X className="h-6 w-6" />
          </Button>

          <div className="flex-1 flex items-center justify-center p-8">
            <div className="max-w-4xl w-full text-center">
              <p className="text-4xl font-bold whitespace-pre-line">{formatSongContent(selectedSong)[currentSlide]}</p>
            </div>
          </div>

          <div className="absolute bottom-4 left-0 right-0 flex justify-center items-center gap-4">
            <Button variant="outline" size="icon" onClick={handlePrevSlide} disabled={currentSlide === 0}>
              <ChevronRight className="h-6 w-6" />
            </Button>
            <span className="text-sm">
              {currentSlide + 1} من {formatSongContent(selectedSong).length}
            </span>
            <Button
              variant="outline"
              size="icon"
              onClick={handleNextSlide}
              disabled={currentSlide === formatSongContent(selectedSong).length - 1}
            >
              <ChevronLeft className="h-6 w-6" />
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}

