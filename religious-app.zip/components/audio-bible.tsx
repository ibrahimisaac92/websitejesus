"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Search, Play, Pause } from "lucide-react"

interface BibleBook {
  name: string
  chapters: number
}

const bibleBooks: BibleBook[] = [
  { name: "التكوين", chapters: 50 },
  { name: "الخروج", chapters: 40 },
  // Add all other books here
]

export default function AudioBible() {
  const [selectedBook, setSelectedBook] = useState<BibleBook | null>(null)
  const [selectedChapter, setSelectedChapter] = useState<number | null>(null)
  const [audioFile, setAudioFile] = useState<string | null>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    // Simulating search in local folder
    if (selectedBook && selectedChapter) {
      const fileName = `${selectedBook.name}_${selectedChapter}.mp3`
      setAudioFile(`/audio-bible/${fileName}`)
    }
  }, [selectedBook, selectedChapter])

  const handlePlay = () => {
    if (audioFile) {
      // Play audio logic here
      setIsPlaying(true)
    }
  }

  const handlePause = () => {
    // Pause audio logic here
    setIsPlaying(false)
  }

  const filteredBooks = bibleBooks.filter((book) => book.name.toLowerCase().includes(searchQuery.toLowerCase()))

  return (
    <Card>
      <CardHeader>
        <CardTitle>الكتاب المقدس الصوتي</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>بحث عن كتاب</Label>
          <div className="relative">
            <Input
              type="search"
              placeholder="ابحث عن كتاب..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          </div>
        </div>

        <Select onValueChange={(value) => setSelectedBook(bibleBooks.find((book) => book.name === value) || null)}>
          <SelectTrigger>
            <SelectValue placeholder="اختر السفر" />
          </SelectTrigger>
          <SelectContent>
            {filteredBooks.map((book) => (
              <SelectItem key={book.name} value={book.name}>
                {book.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {selectedBook && (
          <Select onValueChange={(value) => setSelectedChapter(Number.parseInt(value))} disabled={!selectedBook}>
            <SelectTrigger>
              <SelectValue placeholder="اختر الإصحاح" />
            </SelectTrigger>
            <SelectContent>
              {Array.from({ length: selectedBook.chapters }, (_, i) => i + 1).map((chapter) => (
                <SelectItem key={chapter} value={chapter.toString()}>
                  الإصحاح {chapter}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}

        <Button className="w-full" onClick={isPlaying ? handlePause : handlePlay} disabled={!audioFile}>
          {isPlaying ? (
            <>
              <Pause className="mr-2 h-4 w-4" /> إيقاف
            </>
          ) : (
            <>
              <Play className="mr-2 h-4 w-4" /> استماع
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  )
}

