"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { jsPDF } from "jspdf"
import "jspdf-autotable"

interface Attendance {
  name: string
  date: string
}

export default function AttendanceRecord() {
  const [servantName, setServantName] = useState("")
  const [serviceName, setServiceName] = useState("")
  const [attendees, setAttendees] = useState<Attendance[]>([])
  const [newName, setNewName] = useState("")

  const handleAddAttendee = () => {
    if (newName) {
      setAttendees([
        ...attendees,
        {
          name: newName,
          date: new Date().toLocaleDateString("ar-EG"),
        },
      ])
      setNewName("")
    }
  }

  const generatePDF = () => {
    try {
      const doc = new jsPDF()

      // Configure document for RTL
      doc.setR2L(true)

      // Create the table data
      const tableData = attendees.map((a) => [a.date, a.name])

      // Add the table using autoTable
      doc.autoTable({
        head: [["تاريخ الحضور", "اسم المخدوم"]],
        body: tableData,
        startY: 50,
        theme: "grid",
        styles: {
          halign: "right",
          font: "helvetica",
          fontSize: 12,
        },
        headStyles: {
          fillColor: [0, 0, 0],
          textColor: [255, 255, 255],
          halign: "right",
        },
        didDrawPage: (data) => {
          // Add header on each page
          doc.setFontSize(20)
          doc.text("سجل الحضور والغياب", doc.internal.pageSize.width - 20, 20, { align: "right" })
          doc.setFontSize(14)
          doc.text(`الخادم: ${servantName}`, doc.internal.pageSize.width - 20, 30, { align: "right" })
          doc.text(`الخدمة: ${serviceName}`, doc.internal.pageSize.width - 20, 40, { align: "right" })
        },
      })

      // Save the PDF
      doc.save("attendance.pdf")
    } catch (error) {
      console.error("Error generating PDF:", error)
      alert("حدث خطأ أثناء إنشاء ملف PDF")
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>تسجيل الحضور والغياب</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid gap-4">
          <div className="space-y-2">
            <Label>اسم الخادم</Label>
            <Input value={servantName} onChange={(e) => setServantName(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>اسم الخدمة</Label>
            <Input value={serviceName} onChange={(e) => setServiceName(e.target.value)} />
          </div>
        </div>

        {servantName && serviceName && (
          <>
            <div className="flex gap-2">
              <Input
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="اسم المخدوم"
                onKeyDown={(e) => {
                  if (e.key === "Enter" && newName) {
                    handleAddAttendee()
                  }
                }}
              />
              <Button onClick={handleAddAttendee}>إضافة</Button>
            </div>

            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>اسم المخدوم</TableHead>
                  <TableHead>تاريخ الحضور</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {attendees.map((attendee, index) => (
                  <TableRow key={index}>
                    <TableCell>{attendee.name}</TableCell>
                    <TableCell>{attendee.date}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>

            {attendees.length > 0 && (
              <Button onClick={generatePDF} className="w-full">
                حفظ كملف PDF
              </Button>
            )}
          </>
        )}
      </CardContent>
    </Card>
  )
}

